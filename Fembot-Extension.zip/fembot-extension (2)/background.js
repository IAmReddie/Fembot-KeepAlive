const ALARM_NAME = "fembot-ping";
const PING_INTERVAL_MINUTES = 4;

async function pingServer() {
  const result = await chrome.storage.local.get(["serverUrl", "enabled"]);
  const { serverUrl, enabled } = result;
  if (!enabled || !serverUrl) return;

  try {
    const res = await fetch(serverUrl, { method: "GET", cache: "no-store" });
    const status = res.ok ? "online" : "error";
    await chrome.storage.local.set({ lastPing: Date.now(), lastStatus: status });
  } catch {
    await chrome.storage.local.set({ lastPing: Date.now(), lastStatus: "unreachable" });
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({ enabled: false, lastStatus: "idle", lastPing: null });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) pingServer();
});

chrome.storage.onChanged.addListener(async (changes) => {
  if (changes.enabled) {
    if (changes.enabled.newValue) {
      chrome.alarms.create(ALARM_NAME, { periodInMinutes: PING_INTERVAL_MINUTES });
      await pingServer();
    } else {
      chrome.alarms.clear(ALARM_NAME);
      await chrome.storage.local.set({ lastStatus: "idle" });
    }
  }
});
