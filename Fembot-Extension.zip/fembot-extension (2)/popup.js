const urlInput = document.getElementById("server-url");
const toggle = document.getElementById("enabled-toggle");
const dot = document.getElementById("status-dot");
const statusText = document.getElementById("status-text");
const lastPingEl = document.getElementById("last-ping");

function formatTime(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  return `Last ping: ${d.toLocaleTimeString()}`;
}

function applyStatus(status, lastPing) {
  dot.className = "dot " + (status || "idle");
  const labels = { online: "Online", error: "Server error", unreachable: "Unreachable", idle: "Idle" };
  statusText.textContent = labels[status] || "Idle";
  lastPingEl.textContent = status !== "idle" ? formatTime(lastPing) : "";
}

async function load() {
  const data = await chrome.storage.local.get(["serverUrl", "enabled", "lastStatus", "lastPing"]);
  if (data.serverUrl) urlInput.value = data.serverUrl;
  toggle.checked = !!data.enabled;
  applyStatus(data.lastStatus || "idle", data.lastPing);
}

urlInput.addEventListener("change", async () => {
  await chrome.storage.local.set({ serverUrl: urlInput.value.trim() });
});

toggle.addEventListener("change", async () => {
  await chrome.storage.local.set({ enabled: toggle.checked });
  if (!toggle.checked) applyStatus("idle", null);
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.lastStatus || changes.lastPing) {
    chrome.storage.local.get(["lastStatus", "lastPing"], (data) => {
      applyStatus(data.lastStatus, data.lastPing);
    });
  }
});

load();
